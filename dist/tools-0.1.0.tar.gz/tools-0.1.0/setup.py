# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tools',
 'tools.binary-encoder',
 'tools.columnar-storage',
 'tools.file-directory-structure-maker',
 'tools.run-length-encoder']

package_data = \
{'': ['*'], 'tools.columnar-storage': ['data/*']}

install_requires = \
['pandas>=1.5.0,<2.0.0', 'pytest>=7.1.3,<8.0.0']

setup_kwargs = {
    'name': 'tools',
    'version': '0.1.0',
    'description': 'Random (mostly Python) coding tools and functions',
    'long_description': '# Tools\n\n## Run Length Encoder\n\n## Binary Encoder\n\n## File Directory Structure Maker\n\n## Toolbox\n\n### Human Readable Size\n\n### Glob Multiple Patterns\n\n### Tree',
    'author': 'Chris Birch',
    'author_email': 'datapointchris@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
