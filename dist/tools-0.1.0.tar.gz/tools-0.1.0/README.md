# Tools

## Run Length Encoder

## Binary Encoder

## File Directory Structure Maker

## Toolbox

### Human Readable Size

### Glob Multiple Patterns

### Tree